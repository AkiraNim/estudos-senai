package comportamentos;

public class Nadar {
    public void Nadar() {
        System.out.println("nadar");
    }
}
