package comportamentos;

public class Respirar {
    public Respirar(int q) {
    }

    public void respirar(int qtdeOxigenio) {
        System.out.println("Oxigenio: " + qtdeOxigenio);
    }
}
