package comportamentos;

public class Falar {
    public void falar(String som) {
        System.out.println("Som :" + som);
    }
}
