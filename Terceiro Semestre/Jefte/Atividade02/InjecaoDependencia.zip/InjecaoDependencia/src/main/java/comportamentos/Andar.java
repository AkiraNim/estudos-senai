package comportamentos;

public class Andar {
    public void andar(int velocidade) {
        System.out.println("Velocidade: " + velocidade);
    }
}
