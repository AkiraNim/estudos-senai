public class Cavalo extends Animal {
    public Cavalo(String nome, int idade, String categoria) {
        super(nome, idade, categoria);
    }
}
