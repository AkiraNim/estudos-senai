public class Cachorro extends Animal {
    public Cachorro(String nome, int idade, String categoria) {
        super(nome, idade, categoria);
    }
}
