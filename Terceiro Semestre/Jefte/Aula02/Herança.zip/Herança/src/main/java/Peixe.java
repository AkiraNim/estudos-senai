public class Peixe extends Animal {
    public Peixe(String nome, int idade, String categoria) {
        super(nome, idade, categoria);
    }
}
