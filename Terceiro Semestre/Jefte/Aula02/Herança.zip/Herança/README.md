- [1. Introdução](#1-introdução)
- [2. Casos de Uso](#2-casos-de-uso)

# 1. Introdução

- Nesse exemplo, é demonstração o uso da Herança na _POO_, e seus problemas de **DESIGN**.

# 2. Casos de Uso

- No caso da classe `Animal` existem 3 métodos, andar(), respirar(), falar().
  - Até esse momento, na perspectiva da POO, atende.
  - Mas a partir do momento que entrou a classe `Peixe`, quebrou o principio da POO.