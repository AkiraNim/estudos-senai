package comportamentos;

public class Voar {
    public void voar() {
        System.out.println("voar");
    }
}
