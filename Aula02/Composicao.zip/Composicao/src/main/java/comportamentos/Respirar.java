package comportamentos;

public class Respirar {
    public Respirar() {
    }

    public void respirar(int qtdeOxigenio) {
        System.out.println("Oxigenio: " + qtdeOxigenio);
    }
}
