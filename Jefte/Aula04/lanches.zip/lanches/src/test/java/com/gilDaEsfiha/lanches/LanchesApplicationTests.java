package com.gilDaEsfiha.lanches;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanchesApplicationTests {

	@Test
	void contextLoads() {
	}

}
