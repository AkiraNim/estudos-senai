package tech.buildrun.agregadorinvestimentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgregadorinvestimentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
