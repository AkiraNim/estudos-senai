package tech.buildrun.agregadorinvestimentos.controller;

public record UpdateUserDto(String username, String password) {
}
