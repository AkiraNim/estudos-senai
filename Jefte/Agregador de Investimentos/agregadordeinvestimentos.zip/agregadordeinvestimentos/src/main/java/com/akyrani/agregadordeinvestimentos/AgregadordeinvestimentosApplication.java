package com.akyrani.agregadordeinvestimentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgregadordeinvestimentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgregadordeinvestimentosApplication.class, args);
	}

}
